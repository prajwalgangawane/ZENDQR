sap.ui.define([
    "zend/controller/BaseController",
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/model/xml/XMLModel",
    "sap/m/MessageBox",
    "sap/ndc/BarcodeScanner",
    "sap/m/PDFViewer"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (BaseController, Controller, JSONModel, MessageToast, Filter, FilterOperator, XMLModel, MessageBox, BarcodeScanner, PDFViewer) {
        "use strict";
        var prefixId;
        var oScanResultText;
        var oScanResultTextChange;
        return BaseController.extend("zend.controller.Master", {
            onInit: function () {

                var sUrl = "/sap/opu/odata/sap/ZFORD_SERVICE_SRV/";
                var entitySet = "/ZPACKAGEDATASet";
                var oModel = new sap.ui.model.odata.v2.ODataModel(sUrl, true);
                var oJSONModel = new JSONModel()
                oModel.read(entitySet, {
                    async: false,
                    // urlParameters:["Werks":"1108",],
                    success: function (oData, response) {
                        oJSONModel.setData(oData);
                        // that.getView().getModel().setData(oData)

                        console.log(oData, response);
                    },
                    error: function (oData, response) {
                        console.log("error")
                    }
                });
                console.log(oJSONModel.getData().results)
                this.getView().setModel(oJSONModel, "mainModel");
                sap.ui.getCore().setModel(oJSONModel, "mainModel");
                sap.ui.getCore().setModel(oModel, 'oDataModel');

                var entitySetCombo = '/ZMASTERDATASet';
                var oModelCombo = new sap.ui.model.odata.v2.ODataModel(sUrl, true);
                var oJSONModelCombo = new JSONModel()
                oModelCombo.read(entitySetCombo, {
                    async: false,
                    // urlParameters:["Werks":"1108",],
                    success: function (oData, response) {
                        oJSONModelCombo.setData(oData);
                        // that.getView().getModel().setData(oData)

                        console.log(oData, response);
                    },
                    error: function (oData, response) {
                        console.log("error")
                    }
                });
                console.log(oJSONModelCombo.getData().results)
                this.getView().setModel(oJSONModelCombo, "oJSONModelCombo");
                sap.ui.getCore().setModel(oJSONModelCombo, "oJSONModelCombo");
                sap.ui.getCore().setModel(oModelCombo, 'oModelCombo');

                var createData = [];
                var createModel = new JSONModel(createData);
                this.getView().setModel(createModel, 'createModel');

                // var entitySetMatnrCombo = '/ZCOMBODATASet';
                // var oModelMatnrCombo = new sap.ui.model.odata.v2.ODataModel(sUrl, true);
                // var oJSONModelMatnrCombo = new JSONModel()
                // oModelMatnrCombo.read(entitySetMatnrCombo, {
                //     async: false,
                //     // urlParameters:["Werks":"1108",],
                //     success: function (oData, response) {
                //         oJSONModelMatnrCombo.setData(oData);
                //         // that.getView().getModel().setData(oData)

                //         console.log(oData, response);
                //     },
                //     error: function (oData, response) {
                //         console.log("error")
                //     }
                // });

                // console.log(oJSONModelMatnrCombo.getData().results)
                // this.getView().setModel(oJSONModelMatnrCombo, "oJSONModelMatnrCombo");
                // sap.ui.getCore().setModel(oJSONModelMatnrCombo, "oJSONModelMatnrCombo");
                // sap.ui.getCore().setModel(oModelMatnrCombo, 'oModelMatnrCombo');

                //Scann QR
                prefixId = this.createId();
                if (prefixId) {
                    prefixId = prefixId.split('--')[0] + '--' + prefixId.split('--')[1] + '--';
                } else {
                    prefixId = "";
                }
                oScanResultText = sap.ui.getCore().byId(prefixId + 'scanQR');
                oScanResultTextChange = sap.ui.getCore().byId(prefixId + 'scanQRChange');
            },
            getSearchFilters: function (sKey, query) {
                // return new Filter({
                //   filters: [
                //     new Filter(sKey, FilterOperator.EQ, query),
                //   ],
                //   and: false,
                // });
                return new sap.ui.model.Filter(sKey, sap.ui.model.FilterOperator.EQ, query)
            },
            onSelect: function (oEvent) {
                console.log(oEvent)
                const fields = ['lableNum', 'lableNumInput', 'changeSubmit', 'changePanel']
                var selectItem = oEvent.getParameter('selectedIndex');
                if (selectItem === 1) {
                    fields.forEach(eid => this.getView().byId(eid).setVisible(true))
                    this.getView().byId('createSubmit').setVisible(false)
                    this.getView().byId('createPanel').setVisible(false)

                } else {
                    fields.forEach(eid => this.getView().byId(eid).setVisible(false))
                    this.getView().byId('createSubmit').setVisible(true)
                    this.getView().byId('createPanel').setVisible(true)
                }
            },

            debugBase: function (baseUrl) {
                var win = window.open();
                win.document.write('<iframe src="' + baseUrl + '" frameborder="0" style="border:0; top:0px; left:0px; bottom:0px; right:0px; width:100%; height:100%;" allowfullscreen />');
                // setTimeout(()=>win.print(), 1000);
                win.print();
            },
            onDatachange: function () {
                var filterModel = this.getView().getModel('mainModel');
                var plantComboBox = this.getView().byId("plantNo").getValue();
                var matnrComboBox = this.getView().byId("etlNo").getProperty('value')
                // var urlParameters={'Werks':plantComboBox, 'Matnr':matnrComboBox };
                // var oFilter = Object.keys(urlParameters).map(i=>this.getSearchFilters(i,urlParameters[i]))
                var filterData = filterModel.getData().results.filter((item, index) => item.Matnr === matnrComboBox && item.Werks === plantComboBox)
                if (filterData.length > 0) {
                    var secModel = new JSONModel(filterData)
                    this.getView().setModel(secModel, "secModel");

                } else {
                    MessageToast.show("Plant and document not matching..")
                }
            },
            onSubmit: function (oEvent) {
                console.log(oEvent)
                this.onDatachange();
                this.getView().byId('partNo').setText('0')
                this.getView().byId('packNo').setText(this.getView().getModel('secModel').getData()[0].Totalpkg)
                this.getView().byId('desc').setText(this.getView().getModel("secModel").getData()[0].Maktx)
                this.getView().byId('custNo').setText(this.getView().getModel("secModel").getData()[0].Kdmat)
                var scannerQR = this.getView().byId('scanQR').focus();
                // var oFilter = new sap.ui.model.Filter("Srnos", sap.ui.model.FilterOperator.EQ, '123427')
                // var that = this;




            },
            onPress: function (oEvent) {
                console.log(oEvent)
                var myModel = this.getView().getModel('mainModel')
                var sPath = oEvent.getSource().getBindingContextPath();
                var splitPath = parseInt(sPath.split('/').pop())
                var filterData = myModel.getData().results.filter((item, index) => index === splitPath).pop()
                // var headerModel = new JSONModel(filterData);
                // this.getView().setModel(headerModel, "headerModel");
                // this.getView().byId('desc').setProperty('value', "hey")

                // this.getView().byId('partNo').setText(filterData.Maktx)
            },


            onAdd: function (oEvent) {
                var scanInput = this.getView().byId('scanQR');
                var tableModel = this.getView().getModel('createModel')
                var sPlant = this.getView().byId('scanQR').getValue().split(' ')[0]
                var sSerialNo = this.getView().byId('scanQR').getValue().split(' ')[1]
                var sDate = this.getView().byId('scanQR').getValue().split(' ')[2]
                // console.log(moment.utc(sDate).format('YYYY-MM-DD HH:MM:SS'));
                // var dDate = sDate.slice(4,6) + '.' + sDate.slice(2,4) + '.' + '20' + sDate.slice(0,2)
                var dDate = new Date('20' + sDate.slice(0, 2) + '-' + sDate.slice(2, 4) + '-' + sDate.slice(4)).toISOString().split('Z').join("")
                var sYear = '20' + sDate.slice(0, 2)
                if (scanInput.getValue().length <= 32) {
                    var sCustNo = this.getView().byId('scanQR').getValue().split(' ')[3];
                } else {
                    var sCustNo = this.getView().byId('scanQR').getValue().split('  ')[1];
                }
                var ocreateObj = { 'Werks': '', 'Mjahr': '', 'Matnr': '', 'Srnos': '', 'Sdate': '', 'Kdmat': '', 'Pkgno': '', 'Labno': '' };

                ocreateObj.Werks = sPlant
                ocreateObj.Mjahr = sYear
                ocreateObj.Srnos = sSerialNo
                ocreateObj.Sdate = dDate
                // ocreateObj.Sdate = '2023-09-14T00:00:00'
                ocreateObj.Kdmat = sCustNo
                // ocreateObj.Pkgno = tableModel.getData().length
                ocreateObj.Matnr = this.getView().getModel('secModel').getData()[0].Matnr
                // this.getView().byId('custPart').setTitle(sCustNo)
                // this.getView().byId('year').setTitle(sYear)
                // this.getView().byId('serialNo').setTitle(sSerialNo)
                this.getView().byId('sdate').setTitle(dDate.split('T')[0])
                var tableCheck = tableModel.getData().find(i => sSerialNo == i.Srnos);
                if (tableCheck === undefined) {
                    if (tableModel.getData().length < this.getView().getModel('secModel').getData()[0].Totalpkg) {
                        tableModel.getData().push(ocreateObj)
                        this.getView().byId('partNo').setText(tableModel.getData().length)
                    } else {
                        MessageToast.show('Packages Full')
                    }
                } else {
                    MessageToast.show('Record already exists')
                }
                tableModel.refresh(true);
                // this.getOwnerComponent().getModel().create('/ZPACKAGEDATASet', )


            },
            onInsert: function () {
                var tableModel = this.getView().getModel('createModel').getData();
                var changeModel = this.getView().getModel('detailModel');

                // tableModel.map((row,i)=>{
                //     row.Pkgno = tableModel.length
                //     console.log(tableModel.length);
                //     if(i == 0){
                //                row.Labno = 1;
                //             }else{
                //                 row.Labno = 0;
                //             }
                //             return row; 
                // })

                // tableModel.map(async(row,i)=>await this.getOwnerComponent().getModel().create("/ZPACKDATASet", row,{
                //     success:(data,response)=>{
                //         console.log(data,response)
                //         if( i === tableModel.length-1){
                // MessageToast.show("data created");

                //         } 
                //     }
                // }))

                // tableModel


                // return
                for (var i = 0; i < tableModel.length; i++) {

                    tableModel[i].Pkgno = tableModel.length
                    console.log(tableModel[i]);
                    if (i == 0) {
                        tableModel[i].Labno = 1;
                    } else {
                        tableModel[i].Labno = 0;
                    }
                    // tableModel[0].Labno = 1;
                    // tableModel[1].Labno = 0;
                    // return;
                    var newTableModel = tableModel[i]
                    this.getOwnerComponent().getModel().create("/ZPACKAGEDATASet", tableModel[i], {
                        success: function (data, response) {
                            console.log(response)
                            console.log(data)
                            // if(tableModel.length){
                            console.log(changeModel)
                            MessageToast.show("Data Created with Label No. " + data.Labno);
                            this.getView().getModel('createModel').setData()
                            this.getView().byId('partNo').setText('0')
                            this.getView().byId('scanQR').setValue('');

                            var sUrl = "/sap/opu/odata/sap/ZFORD_SERVICE_SRV/";
                            var entitySet = "/ZPACKAGEDATASet";
                            var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
                            var oJSONModel = new JSONModel()
                            oModel.read(entitySet, {
                                async: false,
                                // urlParameters:["Werks":"1108",],
                                success: function (oData, response) {
                                    oJSONModel.setData(oData);
                                    // that.getView().getModel().setData(oData)

                                    console.log(oData, response);
                                }.bind(this),
                                error: function (oData, response) {
                                    console.log("error")
                                }
                            });
                            console.log(oJSONModel.getData().results)
                            //    this.getView().setModel(oJSONModel, "mainModel");
                            sap.ui.getCore().setModel(oJSONModel, "mainModel");

                            // }
                        }.bind(this),
                        error: function (error) {
                            MessageToast.show("Error while creating the data");
                        }
                    });
                }
                // return;

            },

            oSubmit: function (oEvent) {
                console.log(oEvent);
                this.onDatachange();

                var filterModel = sap.ui.getCore().getModel('mainModel');


                // var filterModel = this.getOwnerComponent().getModel().oData;
                // var objData = Object.keys(filterModel).map((key) => filterModel[key])
                // filterModel.refresh(true);
                var plantComboBox = this.getView().byId("plantNo").getValue();
                var matnrComboBox = this.getView().byId("etlNo").getProperty('value')
                var labelInputField = this.getView().byId("lableNumInput").getProperty('value')
                // var filterData = objData.filter((item,index) => item.Matnr === matnrComboBox && item.Werks === plantComboBox && item.Labno == labelInputField)
                var filterData = filterModel.getData().results.filter((item, index) => item.Matnr === matnrComboBox && item.Werks === plantComboBox && item.Labno == labelInputField)
                if (filterData.length > 0) {
                    var detailModel = new JSONModel(filterData)
                    this.getView().setModel(detailModel, "detailModel");
                    sap.ui.getCore().setModel(detailModel, "detailModel")
                    // this.getView().byId('packNo').setText(this.getView().getModel('secModel').getData()[0].Totalpkg)
                    this.getView().byId('descChange').setText(filterData[0].Maktx)
                    this.getView().byId('custNoChange').setText(filterData[0].Kdmat)
                    this.getView().byId('partNoChange').setText('0')
                    var scannerQR = this.getView().byId('scanQRChange').focus();
                    this.getView().byId('packNoChange').setText(filterData[0].Pkgno)
                    this.getView().byId('partNoChange').setText(this.getView().getModel('detailModel').getData().length)
                } else {
                    MessageToast.show("Add valid input!");
                }
            },
            onAddChange: function () {
                var sPlant = this.getView().byId('scanQRChange').getValue().split(' ')[0]
                var sSerialNo = this.getView().byId('scanQRChange').getValue().split(' ')[1]
                var sDate = this.getView().byId('scanQRChange').getValue().split(' ')[2]
                var dDate = new Date('20' + sDate.slice(0, 2) + '-' + sDate.slice(2, 4) + '-' + sDate.slice(4)).toISOString().split('Z').join("")
                var sYear = '20' + sDate.slice(0, 2)
                var sCustNo = this.getView().byId('scanQRChange').getValue().split(' ')[3];

                var ocreateObj = { 'Werks': '', 'Mjahr': '', 'Matnr': '', 'Srnos': '', 'Sdate': '', 'Kdmat': '', 'Pkgno': '', 'Labno': '' };

                ocreateObj.Werks = sPlant
                ocreateObj.Mjahr = sYear
                ocreateObj.Srnos = sSerialNo
                ocreateObj.Sdate = dDate
                ocreateObj.Kdmat = sCustNo
                ocreateObj.Matnr = this.getView().getModel('secModel').getData()[0].Matnr

                var oDetailModel = this.getView().getModel('detailModel')

                // this.getView().byId('sdate').setTitle(dDate.split('T')[0])
                var tableCheck = oDetailModel.getData().find(i => sSerialNo == i.Srnos);
                if (tableCheck === undefined) {
                    if (oDetailModel.getData().length < this.getView().byId('packNoChange').getText()) {
                        oDetailModel.getData().push(ocreateObj)
                        this.getView().byId('partNoChange').setText(oDetailModel.getData().length)
                    } else {
                        MessageToast.show('Packages Full')
                    }
                } else {
                    MessageToast.show('Record already exists')
                }
                oDetailModel.refresh(true);


            },
            onDelete: async function (oEvent) {
                console.log(oEvent)
                var that = this

                var oDetailPress = that.getView().getModel('detailModel');
                var changeTable = this.getView().byId('changeTable').getBindingInfo('items').binding.oList;
                var sPath = oEvent.getSource().getParent().getBindingContextPath().split('/').pop()
                // var newData = changeTable.filter((item,index) => index == sPath).pop();
                var newData = oDetailPress.getData().splice(sPath, 1).pop();
                await sap.ui.getCore().getModel('oDataModel').remove("/ZPACKAGEDATASet(Werks='" + newData.Werks + "',Matnr='" + newData.Matnr + "',Mjahr='" + newData.Mjahr + "',Srnos='" + newData.Srnos + "')", {
                    //   ','+'Mjahr='+'2008'+','+'Srnos='+'999999'+"')", {
                    method: "DELETE",
                    success: function (data) {
                        MessageToast.show("Customer deleted Successfully");
                        // that.handleMasterListRefresh()
                        // var sUrl = "/sap/opu/odata/sap/ZFORD_SERVICE_SRV/";
                        //        var entitySet = "/ZPACKAGEDATASet";
                        //        var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
                        //        var oDetailPress = that.getView().getModel('detailModel');
                        //        oModel.read(entitySet, {
                        //         async: false,
                        //         // urlParameters:["Werks":"1108",],
                        //         success: function (oData, response) {
                        //             oDetailPress.setData(oData);
                        //             // that.getView().getModel().setData(oData)

                        //             console.log(oData, response);
                        //         },
                        //         error: function (oData, response) {
                        //             console.log("error")
                        //         }
                        //     });
                        //     console.log(oDetailPress.getData().results)
                        // sap.ui.getCore().getModel('oDataModel').refresh(true);
                    },
                    error: function (e) {
                        MessageToast.show("Customer deletion Failed");
                    }

                });
                oDetailPress.refresh(true);
            },
            changeSubmit: async function () {
                var dModel = this.getView().getModel('detailModel').getData();
                for (let i = 0; i < dModel.length; i++) {

                    dModel[i].Pkgno = this.getView().getModel('detailModel').getData().length;
                    if (i >= 1) {
                        dModel[i].Labno = 0
                    }
                    // dModel[i].Pkgno = this.getView().byId('packNo').getText();
                    console.log(dModel[i]);

                    await this.getOwnerComponent().getModel().create("/ZPACKAGEDATASet", dModel[i], {
                        success: function (data, response) {
                            console.log(response)
                            console.log(data)
                            // if(tableModel.length){
                            this.getView().getModel('detailModel').setData()
                            this.getView().byId('scanQRChange').setValue('')
                            this.getView().byId('partNoChange').setText('0')
                            MessageToast.show("Data Created with Label No. " + data.Labno);

                            var sUrl = "/sap/opu/odata/sap/ZFORD_SERVICE_SRV/";
                            var entitySet = "/ZPACKAGEDATASet";
                            var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
                            var oJSONModel = new JSONModel()
                            oModel.read(entitySet, {
                                async: false,
                                // urlParameters:["Werks":"1108",],
                                success: function (oData, response) {
                                    oJSONModel.setData(oData);
                                    // that.getView().getModel().setData(oData)

                                    console.log(oData, response);
                                }.bind(this),
                                error: function (oData, response) {
                                    console.log("error")
                                }
                            });
                            console.log(oJSONModel.getData().results)
                            //    this.getView().setModel(oJSONModel, "mainModel");
                            sap.ui.getCore().setModel(oJSONModel, "mainModel");

                            // }
                        }.bind(this),
                        error: function (error) {
                            MessageToast.show("Error while creating the data");
                        }
                    });
                }
            },
            handleMasterListRefresh: function () {
                var that = this;
                return new Promise(function (resolve) {
                    var oBinding = that.getView().byId('changeTable').getBindings('items');
                    var fnHandler = function () {
                        oBinding.detachDataReceived(fnHandler);
                        resolve();
                    };
                    oBinding.attachDataReceived(fnHandler);
                    oBinding.refresh();
                })
            },
            // onChange: function(oEvent){
            //     var that = this;
            //     BarcodeScanner.scan(
            //         function(mResult){
            //             if(!mResult.cancelled){
            //                 that.getView().byId('scanQR').setValue(mResult.text);
            //                 MessageBox.show("We got a QR Code" + 
            //                 "Result: " + mResult.text + "\n" + 
            //                 "Format: " + mResult.format + "\n");
            //             }
            //         },
            //         function (Error){
            //             alert("Scanning Failed" + Error);
            //         }
            //     )

            // },
            onSuccess: function (oEvent) {
                if (oEvent.getParameter("cancelled")) {
                    MessageToast.show("Scan cancelled", { duration: 1000 });
                } else {
                    if (oEvent.getParameter("text")) {
                        if (this.getView().byId('createBtn').getProperty('selected') === true) {
                            oScanResultText.setValue(oEvent.getParameter("text"));
                            console.log(oEvent.getParameter("text"))
                            this.onAdd();
                        } else {
                            oScanResultTextChange.setValue(oEvent.getParameter("text"));
                            console.log(oEvent.getParameter("text"))
                            this.onAddChange();
                        }

                    } else {
                        oScanResultText.setValue('');
                        oScanResultTextChange.setValue('');
                    }
                }
            },
            onFail: function (oEvent) {
                MessageToast.show("Scan failed: " + oEvent, { duration: 1000 });
            },
            onAfterRendering: function () {
                // Reset the scan result
                var oScanButton = sap.ui.getCore().byId(prefixId + 'sampleButtonScanner');
                var oScanButtonChange = sap.ui.getCore().byId(prefixId + 'sampleButtonScannerChange');
                if (oScanButton) {
                    $(oScanButton.getDomRef()).on("click", function () {
                        oScanResultText.setValue('');

                    });
                }
                if (oScanButtonChange) {
                    $(oScanButtonChange.getDomRef()).on("click", function () {

                        oScanResultTextChange.setValue('');
                    });
                }
            },
            onPrint: function (oEvent) {
                // window.print()
                // globalThis.print();
                // var oView = this.getView()
                // var printPage = document.implementation.createHTMLDocument('masterPage');
                // printPage.head.innerHTML = document.head.innerHTML;
                // printPage.body.innerHTML = document.getElementById('container-zend---Master--page').outerHTML;
                // this.debugBase(`data:text/html,${encodeURIComponent(printPage.head.outerHTML + printPage.body.outerHTML)}`)

                var oDataModelPrint = sap.ui.getCore().getModel('mainModel');
                var newFilterPrintData = oDataModelPrint.getData().results.filter(item => item.Matnr === this.getView().byId('etlNo').getValue() && item.Labno == this.getView().byId('lableNumInput').getValue())
                // var oSendData = {
                //     "Matnr" : newFilterPrintData[0].Matnr,
                //     "Labno" : newFilterPrintData[0].Labno,
                //     "Pkgno" : newFilterPrintData[0].Pkgno,
                //     "Kdmat" : newFilterPrintData[0].Kdmat
                // }

                var sUrl = "/sap/opu/odata/sap/ZFORD_SERVICE_SRV/";
                // var entitySet = "/ZPDFVIEWSet(Labno="+46+")"
                var entitySet = "/ZPDFVIEWSet(Labno=" + newFilterPrintData[0].Labno + ",Matnr='" + '000000003640004051' + "',Pkgno=" + newFilterPrintData[0].Pkgno + ",Kdmat='" + newFilterPrintData[0].Kdmat + "')"
                var oModel = new sap.ui.model.odata.v2.ODataModel(sUrl, true);
                var oJSONModelPrint = new JSONModel()
                var html = new sap.ui.core.HTML();
                var oPanel = this.getView().byId('printpdf')
                oModel.read(entitySet, {
                    async: false,
                    success: function (oData, response) {
                        oJSONModelPrint.setData(oData);
                        // that.getView().getModel().setData(oData)

                        console.log(oData, response);

                        var pdfURL = '/sap/public/DE1075E28E021EDE9DE647FB57A906EF.PDF';

                        html.setContent("<iframe src=" + pdfURL + " width='700' height='700'></iframe>");

                        oPanel.addContent(html);
                        oPanel.placeAt("content");

                        // var opdfViewer = new PDFViewer();
                        // this.getView().addDependent(opdfViewer);
                        // var sServiceURL = this.getView().getModel().sServiceUrl;
                        // var sSource = sServiceURL + "GetPdfSet(Serial='C0003',Filename='')/$value";
                        // opdfViewer.setSource(sSource);
                        // opdfViewer.setTitle("My PDF");
                        // opdfViewer.open();

                        var oHtml = this.getView().byId("idFrame");
                        oHtml.setContent("<iframe src=" + pdfURL + " height='700' width='1300'></iframe>");
                    }.bind(this),
                    error: function (oData, response) {
                        console.log("error")
                    }
                });
                console.log(oJSONModelPrint.getData().results)
                this.getView().setModel(oJSONModelPrint, "oJSONModelPrint");
                sap.ui.getCore().setModel(oJSONModelPrint, "oJSONModelPrint");
                sap.ui.getCore().setModel(oModel, 'oDataModel');

            },
        });
    });
