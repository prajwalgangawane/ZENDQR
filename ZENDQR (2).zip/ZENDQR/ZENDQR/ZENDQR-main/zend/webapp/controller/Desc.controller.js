sap.ui.define([
    "zend/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/ui/model/odata/v2/ODataModel"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, MessageToast, ODataModel) {
        "use strict";
        var prefixId;
        var oScanResultText;
        return Controller.extend("zend.controller.Desc", {
            onInit: function () {
                var comboModel = sap.ui.getCore().getModel("oJSONModelCombo").getData();
                var newComboModelBill = new JSONModel(comboModel);
                this.getView().setModel(newComboModelBill, "newComboModelBill")

                //Scann QR
                prefixId = this.createId();
                if (prefixId) {
                    prefixId = prefixId.split('--')[0] + '--' + prefixId.split('--')[1] + '--';
                } else {
                    prefixId = "";
                }
                oScanResultText = sap.ui.getCore().byId(prefixId + 'billingScan');

                var oComboModel = new JSONModel({
                    vehtype: [],
                    loadtype: [],
                    modetrpt: []
                })


                var sUrl = "/sap/opu/odata/sap/ZFORD_SERVICE_SRV/";

                var oModel = new ODataModel(sUrl, true);

                oModel.read("/ZVEHTYPESet", {
                    async: false,
                    // urlParameters:["Werks":"1108",],
                    success: function (oData, response) {
                        this.getView().getModel("oComboModel").setProperty('/vehtype', oData.results)
                        // that.getView().getModel().setData(oData)

                        console.log(oData, response);
                    }.bind(this),
                    error: function (oData, response) {
                        console.log("error")
                    }
                });

                oModel.read("/ZLOADTYPESet", {
                    async: false,
                    // urlParameters:["Werks":"1108",],
                    success: function (oData, response) {

                        this.getView().getModel("oComboModel").setProperty('/loadtype', oData.results)
                        // that.getView().getModel().setData(oData)

                        console.log(oData, response);
                    }.bind(this),
                    error: function (oData, response) {
                        console.log("error")
                    }
                });

                oModel.read("/ZMODETRPTSet", {
                    async: false,
                    // urlParameters:["Werks":"1108",],
                    success: function (oData, response) {
                        this.getView().getModel("oComboModel").setProperty('/modetrpt', oData.results)
                        // that.getView().getModel().setData(oData)

                        console.log(oData, response);
                    }.bind(this),
                    error: function (oData, response) {
                        console.log("error")
                    }
                });

                this.getView().setModel(oComboModel, "oComboModel");
                sap.ui.getCore().setModel(oComboModel, "oComboModel");

            },

            onSelect: function (oEvent) {
                console.log(oEvent)
                var selectItem = oEvent.getParameter('selectedIndex');
                const fields = ['toLabel',
                    'toInput',
                    'transporter',
                    'transporterInput',
                    'vehicleReg',
                    'vehicleRegInput',
                    'vehicleTypeInput',
                    'loadTypeInput',
                    'modeTrptInput',
                    'vehicleType',
                    'loadType',
                    'modeTrpt',

                ]
                if (selectItem === 1) {
                    fields.forEach(eid => this.getView().byId(eid).setVisible(true))
                } else {
                    fields.forEach(eid => this.getView().byId(eid).setVisible(false))
                }
            },
            onSubmit: async function (oEvent) {


                var plantValue = this.getView().byId('plantComboBill').getProperty('value');
                if (this.getView().byId('createBtn').getProperty('selected') === true) {
                    var flagData = '0'

                } else {
                    var flagData = '1'

                }
                // if(this.getView().byId('delInput').getProperty('value')>0){
                if (plantValue.length > 0) {
                    var delValue = this.getView().byId('delInput').getProperty('value');
                    if (delValue > 0) {
                        if (this.getView().byId('createBtn').getProperty('selected') === true) {
                            var oFilterBilling = new sap.ui.model.Filter({
                                // path: "Werks" & "Vbeln",
                                // operator: sap.ui.model.FilterOperator.EQ,
                                // value1: plantValue,
                                // value2: delValue,
                                // value3: this.getView().byId('salesOrg').getValue()
                                filters: [
                                    new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, plantValue),
                                    new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, delValue),
                                    new sap.ui.model.Filter("Flag", sap.ui.model.FilterOperator.EQ, flagData)
                                ]
                            })
                        } else {
                            if (this.getView().byId('toInput').getValue().length > 0) {
                                var oFilterBilling = new sap.ui.model.Filter({
                                    filters: [
                                        new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, plantValue),
                                        new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.EQ, this.getView().byId('transporterInput').getValue()),

                                        new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.BT, delValue, this.getView().byId('toInput').getValue()),
                                        new sap.ui.model.Filter("Flag", sap.ui.model.FilterOperator.EQ, flagData),
                                        new sap.ui.model.Filter("Vehno", sap.ui.model.FilterOperator.EQ, this.getView().byId('vehicleRegInput').getValue()),
                                        new sap.ui.model.Filter("VEHTYPE", sap.ui.model.FilterOperator.EQ, this.getView().byId('vehicleTypeInput').getValue()),
                                        new sap.ui.model.Filter("LOADTYPE", sap.ui.model.FilterOperator.EQ, this.getView().byId('loadTypeInput').getValue()),
                                        new sap.ui.model.Filter("MODETRPT", sap.ui.model.FilterOperator.EQ, this.getView().byId('modeTrptInput').getValue()),

                                    ]
                                })
                            } else {
                                var oFilterBilling = new sap.ui.model.Filter({
                                    filters: [
                                        new sap.ui.model.Filter("Werks", sap.ui.model.FilterOperator.EQ, plantValue),
                                        new sap.ui.model.Filter("Lifnr", sap.ui.model.FilterOperator.EQ, this.getView().byId('transporterInput').getValue()),

                                        new sap.ui.model.Filter("Vbeln", sap.ui.model.FilterOperator.EQ, delValue),
                                        new sap.ui.model.Filter("Flag", sap.ui.model.FilterOperator.EQ, flagData),
                                        new sap.ui.model.Filter("Vehno", sap.ui.model.FilterOperator.EQ, this.getView().byId('vehicleRegInput').getValue()),
                                        new sap.ui.model.Filter("Vehtype", sap.ui.model.FilterOperator.EQ, this.getView().byId('vehicleTypeInput').getValue()),
                                        new sap.ui.model.Filter("Loadtype", sap.ui.model.FilterOperator.EQ, this.getView().byId('loadTypeInput').getValue()),
                                        new sap.ui.model.Filter("Modetrpt", sap.ui.model.FilterOperator.EQ, this.getView().byId('modeTrptInput').getValue()),

                                    ]
                                })
                            }

                        }
                        // if () {

                        // }
                        var sUrl = "/sap/opu/odata/sap/ZFORD_SERVICE_SRV/";
                        var entitySet = "/ZBILLINGDATASet";
                        // var laFilter = this.getView().byId('delInput').getValue();
                        var oBillModel = new sap.ui.model.odata.v2.ODataModel(sUrl, true);
                        // var oBillJSONModel = new JSONModel()
                        var oBillJSONModel = new JSONModel({
                            GT_DTL: [],
                            GT_ST: [],
                            GT_ST7: []
                        })
                        await oBillModel.read(entitySet, {
                            async: false,
                            filters: [oFilterBilling.aFilters],
                            // urlParameters:["Vbeln"="0810002336", lifnr = 0000500000 , vehType = 10, loadtype = 11, modetranpt = 10],
                            success: function (oData, response) {
                                // oBillJSONModel.setData(sap.ui.getCore().getModel('newModel').getData().results.filter((item, index) => item.Tabname === 'GT_DTL'));
                                // oBillTabModel.set()
                                // that.getView().getModel().setData(oData)

                                //GT_DTL
                                sap.ui.getCore().getModel('newModel').getProperty('/GT_DTL').push.apply(sap.ui.getCore().getModel('newModel').getProperty('/GT_DTL'), oData.results.filter((item, index) => item.Tabname === 'GT_DTL'))
                                sap.ui.getCore().getModel('newModel').setProperty('/GT_DTL', sap.ui.getCore().getModel('newModel').getProperty('/GT_DTL'))

                                //GT_ST
                                sap.ui.getCore().getModel('newModel').getProperty('/GT_ST').push.apply(sap.ui.getCore().getModel('newModel').getProperty('/GT_ST'), oData.results.filter((item, index) => item.Tabname === 'GT_ST'))
                                sap.ui.getCore().getModel('newModel').setProperty('/GT_ST', sap.ui.getCore().getModel('newModel').getProperty('/GT_ST'))

                                //GT_ST7
                                sap.ui.getCore().getModel('newModel').getProperty('/GT_ST7').push.apply(sap.ui.getCore().getModel('newModel').getProperty('/GT_ST7'), oData.results.filter((item, index) => item.Tabname === 'GT_ST7'))
                                sap.ui.getCore().getModel('newModel').setProperty('/GT_ST7', sap.ui.getCore().getModel('newModel').getProperty('/GT_ST7'))


                                console.log(oData, response);
                            },
                            error: function (oData, response) {
                                console.log("error")
                                MessageToast.show(oData.responseText.split('\"')[15])
                            }
                        });
                        console.log(oBillJSONModel.getData().results)
                        this.getView().setModel(oBillJSONModel, "newModel");
                        sap.ui.getCore().setModel(oBillJSONModel, "newModel");
                        // if(sap.ui.getCore().getModel('newModel').getData().GT_DTL.length === 0 ){
                        //     MessageToast.show('Invalid delivery number...')
                        // }
                        // var newFilterData = this.getView().getModel('newModel').getData().results.filter((item, index) => item.Vbeln === this.getView().byId('delInput').getProperty('value'));
                        // var newJson = new JSONModel(newFilterData);
                        // this.getView().setModel(newJson, 'newJson');


                        // var fullModel = sap.ui.getCore().getModel('billModel');
                        // var arrayData = Object.keys(fullModel.getData().results).map((key) => fullModel.getData().results[key])
                        // var filterField = arrayData.filter((item, index) => item.Vbeln === delValue)
                        // var newModel = new JSONModel(filterField);
                        // this.getView().setModel(newModel, "newModel")
                    } else {
                        alert("Please add Delivery...")

                    }
                } else {
                    alert("Please add Plant...")
                }


            },
            onBillPress: function () {
                var billModel = this.getView().getModel('newModel').getData();

                var scanID = this.getView().byId('billingScan');
                var matnrBill = scanID.getValue().split('-')[0];
                var labnoBill = scanID.getValue().split('-')[1];
                // var pkgnoBill = scanID.getValue().split('-')[2];
                // var findData = this.getView().getModel('newModel').getData().results.find(i => matnrBill)
                // findData.Pkgno = '5';
                this.getView().getModel('newModel').refresh(true)
                var gtDtl = billModel.GT_DTL
                var gtSt = billModel.GT_ST
                var gtSt7 = billModel.GT_ST7

                //sort table st7 
                var lw_st = gtSt7.filter((item, index) => item.Werks === this.getView().byId('plantComboBill').getValue() && item.Matnr === matnrBill && item.Labno == labnoBill);

                if (lw_st.length >= 1) {
                    MessageToast.show("Already scanned...");
                }
                else {
                    var indexST = gtSt.findIndex(item => item.Werks === this.getView().byId('plantComboBill').getValue() && item.Matnr === matnrBill && item.Labno == labnoBill)
                    var ls_st = gtSt.filter((item, index) => item.Werks === this.getView().byId('plantComboBill').getValue() && item.Matnr === matnrBill && item.Labno == labnoBill);
                    if (ls_st.length === 0) {
                        MessageToast.show("Scanned record not found...");
                    }
                    else {
                        var ln = gtSt.findIndex(item => item.Labno == labnoBill);
                        if (ls_st[0].Flag === 'X') {
                            MessageToast.show('Already scanned...')
                        }
                        else {
                            if (ln >= 0 && ln != 1) {
                                var lnl = ln - 1;
                                var ls_st7 = gtSt.filter((item, index) => index === lnl);
                                if (ls_st7.length > 0 && ls_st7[0].Flag === '' && ls_st7[0].Matnr === matnrBill) {
                                    MessageToast.show('Please scan previous Label.. ' + ls_st7[0].Labno);
                                }
                                else {
                                    var lvCheck = 'X';
                                }

                            }
                            else {
                                var lvCheck = 'X';
                            }
                        }
                    }
                }

                if (lvCheck === 'X') {
                    var indexDtl = gtDtl.findIndex(item => item.Matnr == matnrBill)
                    var lw_dtl = gtDtl.filter((item, index) => item.Matnr === matnrBill);
                    if (lw_dtl.length != 0) {
                        lw_dtl[0].Pkgno = lw_dtl[0].Pkgno + ls_st[0].Pkgno;
                        if (lw_dtl[0].Pkgno > lw_dtl[0].Lfimg) {
                            MessageToast.show('Exceeded qty not allowed..')
                        }
                        else {
                            gtDtl[indexDtl].Pkgno = lw_dtl[0].Pkgno;
                            gtSt[indexST].Vbeln = lw_dtl[0].Vbeln;
                            gtSt[indexST].Posnr = lw_dtl[0].Posnr;
                            gtSt[indexST].Flag = 'X';
                        }
                    }
                }
                sap.ui.getCore().getModel('newModel').refresh();
                this.getView().byId('table').getBinding('items').refresh()
            },
            onSend: function (oEvent) {
                var combData = this.getView().getModel('newModel').getData();
                var combDTL = combData.GT_DTL;
                var combST = combData.GT_ST;
                var combST7 = combData.GT_ST7;
                // combDTL.filter(item=>item.Matnr === this.getView().byId('billingScan').getValue().split('-')[0])[0].Labno = this.getView().byId('billingScan').getValue().split('-')[1]

                // var filterDTL = combDTL.filter(item=>item.Matnr === this.getView().byId('billingScan').getValue().split('-')[0])[0]
                // filterDTL.Labno = this.getView().byId('billingScan').getValue().split('-')[1]
                var concatDTL = combDTL.concat(combST);
                var concatData = concatDTL.concat(combST7);
                if (this.getView().byId('createBtn').getProperty('selected') === true) {
                    // concatData.map(({Lifnr,...data})=>({...data}))
                    concatData.map(element => element.Flag === '' ? element.Flag = "0" : element.Flag)
                    // concatData.map(element => element.Lifnr===''? element.Lifnr="0000000000":element.Lifnr)    
                } else {

                    concatData.map(element => element.Flag === '' ? element.Flag = "1" : element.Flag)
                }

                //validation for park and submit button
                if (oEvent.getSource().getProperty('text') === 'Save') {
                    concatData.map(element => element.Pstyv === '' ? element.Pstyv = "0" : element.Pstyv)
                } else {
                    concatData.map(element => element.Pstyv === '' ? element.Pstyv = "1" : element.Pstyv)
                }


                concatData.map(element => element.Lfdat === null ? element.Lfdat = "\/Date(1696809600000)\/" : element.Lfdat)
                var itemsData = concatData.map(({ __metadata, ...data }) => ({ ...data }))
                var extData = { Mjahr: '0000', Srnos: '', Sdate: '\/Date(1696809600000)\/', Erdat: '\/Date(1696809600000)\/', Ertim: 'PT00H00M00S', Ernam: '' }
                // var emptyString = itemsData.map(element => element.Lfdat===null? element.Lfdat='00000000':element.Lfdat)
                var newData = itemsData.map(({ ...data }) => ({ ...data, ...extData }))
                var items = {
                    "Werks": this.getView().byId('plantComboBill').getProperty('value'),
                    "Vbeln": this.getView().byId('delInput').getProperty('value'),
                    "Items": newData
                }

                // var items = {
                //     "Werks" : "1108",
                //     "Vbeln" : "810002336",
                //     "Items":[{
                //     "Werks" : "1108",
                //     "Matnr" : "3640004051",
                //     "Mjahr" : "0000",
                //     "Srnos" : "",
                //     "Sdate" : "\/Date(1696809600000)\/",
                //     "Kdmat" : "",
                //     "Pkgno" : 4,
                //     "Labno" : 43,
                //     "Erdat" : "\/Date(1696809600000)\/",
                //     "Ertim" : "PT00H00M00S",
                //     "Ernam" : "",
                //     "Vbeln" : "810002336",
                //     "Lfdat" : "\/Date(1696809600000)\/",
                //     "Vbelv" : "",
                //     "Maktx" : "",
                //     "Totalpkg" : 0,
                //     "Posnr" : "000010",
                //     "Pstyv" : "",
                //     "Lfimg" : "13270.000",
                //     "Meins" : "EA",
                //     "Tabname" : "",
                //     "Flag" : ""
                //     }]}
                // console.log(this.getOwnerComponent().getModel().read("/ZBILLINGHEADERSet"));
                // return;
                // if (combDTL[0].Pkgno == combDTL[0].Lfimg) {
                this.getOwnerComponent().getModel().create("/ZBILLINGHEADERSet", items, {
                    success: function (data, response) {
                        console.log(response)
                        console.log(data)
                        // if(tableModel.length){
                        // console.log(changeModel)
                        if (oEvent.getSource().getProperty('text') === 'Save') {
                            MessageToast.show('Billing document created.....' + data.Items.results[0].Vbelv)
                        }else{
                            MessageToast.show('Record scanned...');
                        }
                        // this.getView().getModel('createModel').setData()
                        // this.getView().byId('partNo').setText('0')
                        // this.getView().byId('scanQR').setValue('');

                        //     var sUrl = "/sap/opu/odata/sap/ZFORD_SERVICE_SRV/";
                        //    var entitySet = "/ZPACKAGEDATASet";
                        //    var oModel = new sap.ui.model.odata.ODataModel(sUrl, true);
                        //    var oJSONModel = new JSONModel()
                        //    oModel.read(entitySet, {
                        //        async: false,
                        //        // urlParameters:["Werks":"1108",],
                        //        success: function (oData, response) {
                        //            oJSONModel.setData(oData);
                        //            // that.getView().getModel().setData(oData)

                        //            console.log(oData, response);
                        //        }.bind(this),
                        //        error: function (oData, response) {
                        //            console.log("error")
                        //        }
                        //    });
                        //    console.log(oJSONModel.getData().results)
                        // //    this.getView().setModel(oJSONModel, "mainModel");
                        //    sap.ui.getCore().setModel(oJSONModel, "mainModel");

                        // }
                    }.bind(this),
                    error: function (error) {
                        MessageToast.show("Error while creating the data");
                        console.log("error", error);
                    }
                });
                // } 
                // else {
                // MessageToast.show("Still all qty not scanned...")
                // }

            },
            onSuccess: function (oEvent) {
                if (oEvent.getParameter("cancelled")) {
                    MessageToast.show("Scan cancelled", { duration: 1000 });
                } else {
                    if (oEvent.getParameter("text")) {
                        if (this.getView().byId('createBtn').getProperty('selected') === true) {
                            oScanResultText.setValue(oEvent.getParameter("text"));
                            console.log(oEvent.getParameter("text"))
                            this.onBillPress()
                        }

                    } else {
                        oScanResultText.setValue('');

                    }
                }
            },
            onFail: function (oEvent) {
                MessageToast.show("Scan failed: " + oEvent, { duration: 1000 });
            },
            onAfterRendering: function () {
                // Reset the scan result
                var oScanButton = sap.ui.getCore().byId(prefixId + 'sampleButtonScanner');

                if (oScanButton) {
                    $(oScanButton.getDomRef()).on("click", function () {
                        oScanResultText.setValue('');

                    });
                }

            }
            //810002308
        });
    });
