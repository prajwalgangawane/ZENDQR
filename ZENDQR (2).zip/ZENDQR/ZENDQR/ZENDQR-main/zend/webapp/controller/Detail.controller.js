sap.ui.define([
    // "sap/ui/core/mvc/Controller",
    "zend/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast"
],
    /**
     * @param {typeof sap.ui.core.mvc.Controller} Controller
     */
    function (Controller, JSONModel, MessageToast) {
        "use strict";

        return Controller.extend("zend.controller.Detail", {
            onInit: function () {
              var comboModel=  sap.ui.getCore().getModel("oJSONModelCombo").getData();
              var newComboModel = new JSONModel(comboModel);
              this.getView().setModel(newComboModel, "newComboModel")
            },
            onDetailPress:function(oEvent){
                
                var filterModel = sap.ui.getCore().getModel('mainModel');
                // var filterModel = this.getOwnerComponent().getModel().oData;
                // var objData = Object.keys(filterModel).map((key) => filterModel[key])
                // filterModel.refresh(true);
                var plantComboBox = this.getView().byId("plantNo").getValue();
                var matnrComboBox = this.getView().byId("etlNo").getProperty('value')
                var labelInputField = this.getView().byId("lableNumInput").getProperty('value')
                // var filterData = objData.filter((item,index) => item.Matnr === matnrComboBox && item.Werks === plantComboBox && item.Labno == labelInputField)
                var filterData = filterModel.getData().results.filter((item,index) => item.Matnr === matnrComboBox && item.Werks === plantComboBox && item.Labno == labelInputField)
                if (filterData.length>0) {
                    this.getView().byId('detailDesc').setValue(filterData[0].Maktx)
                    this.getView().byId('detailCust').setValue(filterData[0].Kdmat)
                    this.getView().byId('detailPack').setValue(filterData[0].Pkgno)
                    this.getView().byId('detailPart').setValue(filterData.length)
                    var detailModel = new JSONModel(filterData)
                    this.getView().setModel(detailModel, "detailModel");
                }else{
                    MessageToast.show("Please add valid input...")
                }
                
            }
        });
    });
