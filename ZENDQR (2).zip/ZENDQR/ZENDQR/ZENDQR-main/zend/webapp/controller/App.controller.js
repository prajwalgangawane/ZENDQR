sap.ui.define(
  [
    // "sap/ui/core/mvc/Controller"
    "zend/controller/BaseController"
  ],
  function (BaseController) {
    "use strict";

    return BaseController.extend("zend.controller.App", {
      onInit() {
      }
    });
  }
);
