/* global QUnit */

sap.ui.require(["zend/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
