sap.ui.define([
	"zend/test/unit/controller/Master.controller"
], function () {
	"use strict";
});
